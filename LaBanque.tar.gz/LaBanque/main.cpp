#include <iostream>
#include "menu.h"
#include "comptebancaire.h"
#include "compteepargne.h"

/**
 *  @author Matys Brulé
 *  @abstract Main pour le projet Banque
 *  @date 23 septembre 2022
 */
using namespace std;



enum CHOIX_MENU
{
    OPTION_1 = 1,
    OPTION_2,
    OPTION_3,
    OPTION_4,
    OPTION_5,
    QUITTER
};

            //int main()                                        //ETAPE 1 COMPTEBANCAIRE FONCTIONNEL 100%
            //{
            //    try {
            //        float montant;
            //        int choix;
            //        Menu leMenu("../LaBanque/compteBancaire.txt");
            //        CompteBancaire compte(15000);
            //        do {
            //            choix = leMenu.Afficher();
            //            switch (choix)
            //            {
            //            case OPTION_1:
            //                cout << "Consultation du solde" << endl;
            //                cout <<compte.ConsulterSolde()<<endl;
            //                leMenu.AttendreAppuiTouche();
            //                break;
            //            case OPTION_2:
            //                cout << "Montant que vous voulez déposer :" << endl; //FIXME impossible de déposer nbr négatifs
            //                cin >> montant;                                      //mais message "vous avez déposer -5"
            //                compte.Deposer(montant);                             //FIX mais ligne étoile apparait
            //                if(montant < 0 )                                     //FIX endl à la fin.. (cptbancaire.cpp)
            //                {
            //                    break;
            //                }
            //                cout << "Vous avez déposé : " <<montant;
            //                leMenu.AttendreAppuiTouche();
            //                break;
            //            case OPTION_3:
            //                cout << "Montant que vous voulez retirer :" << endl;
            //                cin >> montant;
            //                if(compte.Retirer(montant)==false){
            //                    cout <<"Solde insufisant" <<endl;
            //                }
            //                else {
            //                    cout <<"Vous avez retiré : " <<montant <<endl;
            //                }
            //                leMenu.AttendreAppuiTouche();
            //                break;
            //            }
            //        }while(choix != 4);


            /**
        * @brief catch (exception erreur)
        * Gestion exception pour le menu qui donne un code d'erreur lors d'une erreur.
        *
        */
            //    } catch (Exception erreur) {
            //        erreur.ObtenirMessage();
            //        erreur.ObtenirCodeErreur();
            //        exit(EXIT_FAILURE);
            //    }
            //    return 0;
            //}


int main()
{
    try {
        float montant;
        int choix;
        Menu leMenu("../LaBanque/compteEpargne.txt");
        CompteEpargne compte(5);

        do {
            choix = leMenu.Afficher();
            switch (choix)
            {
            case 1:
                cout << "Consultation du solde" << endl;
                cout <<compte.ConsulterSolde()<< "€" << endl;
                leMenu.AttendreAppuiTouche();
                break;
            case 2:
                cout << "Montant que vous voulez déposer :" << endl;
                cin >> montant;
                compte.Deposer(montant);
                if(montant < 0 )
                {
                    break;
                }
                cout << "Vous avez déposé :  " <<montant << "€";
                leMenu.AttendreAppuiTouche();
                break;
            case 3:
                cout << "Montant que vous voulez retirer : " << endl;
                cin >> montant;
                if(compte.Retirer(montant)==false){
                    cout <<"Solde insufisant" <<endl;
                }
                else {
                    cout <<"Vous avez retiré : " <<montant <<endl;
                }
                leMenu.AttendreAppuiTouche();
                break;
            case 4:
                cout <<"Calcul des interets :" << endl;
                compte.CalculerInterets();
                cout << "Votre nouveau solde après calcul des interets :" <<compte.ConsulterSolde() << "€" << endl;
                break;
            case 5:
                cout <<"Modifier votre taux d'intérêts :" ;
                cin >> montant;


                cout << "Votre nouveau taux d'intérêts après le calcul est de :"  <<endl;
                break;
            }
        }while(choix != 6);

    } catch (Exception erreur) {
        erreur.ObtenirMessage();
        erreur.ObtenirCodeErreur();
        exit(EXIT_FAILURE);
    }
    return 0;
}
