#ifndef COMPTEEPARGNE_H
#define COMPTEEPARGNE_H
#include "comptebancaire.h"


class CompteEpargne : public CompteBancaire
{
private:
    float modiftaux = 0.02;
    float tauxInterets;
public:
    CompteEpargne(const float _tauxInterets);
    //taux intérêts de 2%
    CompteEpargne(const float _solde, const float _tauxInterets);

    void CalculerInterets();
    //calcul du taux d'intérêts
    void ModifierTaux();

};

#endif // COMPTEEPARGNE_H
