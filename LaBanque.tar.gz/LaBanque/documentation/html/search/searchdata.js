var indexSectionsWithContent =
{
  0: "acdeglmnoqrst~",
  1: "cem",
  2: "cm",
  3: "acdegmor~",
  4: "clmnost",
  5: "c",
  6: "oq"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations",
  6: "Valeurs énumérées"
};

