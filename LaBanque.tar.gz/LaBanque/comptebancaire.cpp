#include "comptebancaire.h"


/**
 *  @author Matys Brulé
 *  @abstract Class pour compteBancaire
 *  @date 23 septembre 2022
 */


using namespace std;

/**
 * @brief CompteBancaire::CompteBancaire (Constructeur)
 * @param _solde Solde du compte bancaire
 */


CompteBancaire::CompteBancaire(const float _solde):
    solde(_solde)
{

}
/**
 * @brief CompteBancaire::~CompteBancaire() (Destructeur)
 */

CompteBancaire::~CompteBancaire()
{

}

/**
 * @brief CompteBancaire::Deposer
 *        Méthode pour pouvoir déposer un montant par rapport au solde
 *        elle attend le choix de l'utilisateur pour faire l'addition
 * @return et incrémente le solde par le montant utilisateur
 */

void CompteBancaire::Deposer(const float _montant)
{
    if (_montant > 0){
            solde = solde +_montant;
        }
    else {
            cout << "Impossible d'ajouter des choses négatives" << endl;
        }
}

/**
 * @brief CompteBancaire::Retirer
 *        Méthode similaire au Déposer, à l'inverse elle décrémente.
 *        Elle attend le choix de l'utilisateur pour faire la soustraction
 * @return et décrémente le solde par le montant utilisateur
 */

bool CompteBancaire::Retirer(const float _montant)
{
    bool fix = true;
    if(solde < _montant){
        fix=false;
    }
    else {
        fix=true;
        solde = solde - _montant;
    }
    return fix;
}

/**
 * @brief CompteBancaire::ConsulterSolde
 *        Méthode très simple qui retourne seulement la valeur de solde.
 *
 */


float CompteBancaire::ConsulterSolde()
{
    return solde;
}
