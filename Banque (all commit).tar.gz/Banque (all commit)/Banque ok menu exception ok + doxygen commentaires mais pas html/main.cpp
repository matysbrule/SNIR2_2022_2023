#include <iostream>
#include "menu.h"
#include "comptebancaire.h"

/**
 *  @author Matys Brulé
 *  @abstract Main pour le projet Banque
 *  @date 23 septembre 2022
 */

using namespace std;

enum CHOIX_MENU
{
    OPTION_1 = 1,
    OPTION_2,
    OPTION_3,
    QUITTER
};


int main()
{
    try {
        float montant;
        int choix;
        Menu leMenu("/home/USERS/ELEVES/SNIR2021/mbrule/ProjetQT/SNIR2_2022_2023/Projet_Banque/LaBanque/compteBancaire.txt");
        CompteBancaire compte(15000);
        do {
            choix = leMenu.Afficher();
            switch (choix)
            {
            case OPTION_1:
                cout << "Consultation du solde" << endl;
                cout <<compte.ConsulterSolde()<<endl;
                leMenu.AttendreAppuiTouche();
                break;
            case OPTION_2:
                cout << "Montant que vous voulez déposer :" << endl; //FIXME impossible de déposer nbr négatifs
                cin >> montant;                                      //mais message "vous avez déposer -5"
                compte.Deposer(montant);                             //FIX mais ligne étoile appara
                if(montant < 0 )
                {
                    break;
                }
                cout << "Vous avez déposé : " <<montant;
                leMenu.AttendreAppuiTouche();
                break;
            case OPTION_3:
                cout << "Montant que vous voulez retirer :" << endl;
                cin >> montant;
                if(compte.Retirer(montant)==false){
                    cout <<"Solde insufisant" <<endl;
                }
                else {
                    cout <<"Vous avez retiré : " <<montant <<endl;
                }
                leMenu.AttendreAppuiTouche();
                break;
            }
        }while(choix != 4);


/**
* @brief catch (exception erreur)
* Gestion exception pour le menu qui donne un code d'erreur lors d'une erreur.
*
*/
    } catch (Exception erreur) {
        erreur.ObtenirMessage();
        erreur.ObtenirCodeErreur();
        exit(EXIT_FAILURE);
    }
    return 0;
}
