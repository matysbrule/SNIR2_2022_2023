#include "comptebancaire.h"

CompteBancaire::CompteBancaire(const float _solde):
    solde(_solde)
{

}

CompteBancaire::~CompteBancaire()
{

}

void CompteBancaire::Deposer(const float _montant)
{
    if (_montant > 0){
            solde = solde +_montant;
        }
    else {
            cout << "Impossible d'ajouter des choses négatives";
        }
}

bool CompteBancaire::Retirer(const float _montant)
{
    bool fix = true;
    if(solde < _montant){
        fix=false;
    }
    else {
        fix=true;
        solde = solde - _montant;
    }
    return fix;
}

float CompteBancaire::ConsulterSolde()
{
    return solde;
}
