#include <iostream>
#include "menu.h"
#include "comptebancaire.h"

using namespace std;

enum CHOIX_MENU
{
    OPTION_1 = 1,
    OPTION_2,
    OPTION_3,
    QUITTER
};


int main()
{
    int choix;
    try{
        Menu leMenu("compteBancaire.txt");
        do {
            choix = leMenu.Afficher();
            switch (choix)
            {
            case OPTION_1:
                cout << "Consultation solde" << endl;
                Menu::AttendreAppuiTouche();
                break;
            case OPTION_2:
                cout << "Vous avez choisi d'effectuer un depot" << endl;
                Menu::AttendreAppuiTouche();
                break;
            case OPTION_3:
                cout << "Vous avez choisi d'effectuer un retrait" << endl;
                Menu::AttendreAppuiTouche();
                break;
            }
        } while (choix != QUITTER);
    }catch(std::runtime_error &e){
        cout << e.what() << endl;
        exit(EXIT_FAILURE);
    }

    return 0;
}
