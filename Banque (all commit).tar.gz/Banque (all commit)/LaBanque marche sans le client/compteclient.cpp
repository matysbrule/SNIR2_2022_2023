#include "compteclient.h"

compteClient::compteClient()
{

}
