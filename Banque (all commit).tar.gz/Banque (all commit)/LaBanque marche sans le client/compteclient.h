#ifndef COMPTECLIENT_H
#define COMPTECLIENT_H

#include <string>
using namespace std;

class compteClient
{
protected:

public:
    compteClient(const string _nom, const int _numero);
    ~compteClient();
    void OuvrirCompteEpargne();
    void GererCompteBancaire();
    void GererCompteEpargne();
private:
    CompteBancaire *leCompteBancaire;
    const string nom;
    int numero ;

};



#endif // COMPTECLIENT_H
