#include "compteepargne.h"

/**
 * @brief CompteEpargne::CompteEpargne
 *        Méthode pour initialiser le solde du comptebancaire et
 *        faire les taux d'intér
 *
 * @return
 */


CompteEpargne::CompteEpargne(const float _tauxInterets):
   CompteBancaire(100),
   tauxInterets(_tauxInterets)
{

}

CompteEpargne::CompteEpargne(const float _solde, const float _tauxInterets):
    CompteBancaire(_solde),
    tauxInterets(_tauxInterets)
{

}

void CompteEpargne::CalculerInterets()
{
    float modiftaux = 0.02;
    solde = solde+(solde*modiftaux);
}


