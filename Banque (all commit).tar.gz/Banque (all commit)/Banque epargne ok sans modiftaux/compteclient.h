//#ifndef COMPTECLIENT_H
//#define COMPTECLIENT_H

//using namespace std;

//class compteClient
//{
//    protected
//    const string nom;

//public:
//    compteClient();
//};

//#endif // COMPTECLIENT_H
