#include "comptebancaire.h"

CompteBancaire::CompteBancaire()
{

}
